/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
    float amount, intrest, years;
    printf("enter starting amount, intrest rate and number of years");
    scanf("%f %f %f", &amount, &intrest, &years);
    amount= amount*pow(1+intrest/100,years);
    printf("final amount:%.2f", amount);

    return 0;
}
