/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float num1, num2, num3;
    printf("Enter 3 numbers:");
    scanf("%f %f %f", &num1, &num2, &num3);
    float max=num1;
    if (num2>max) max= num2;
    if (num3>max) max= num3;
    printf("the max is %f", max);
    return 0;
    
}
