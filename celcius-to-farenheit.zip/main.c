/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    float celcius;
    float farenhiet;
    printf("Enter temp in celcius:");
    scanf("%f", &celcius);
    farenhiet=(celcius*4.5+32);
    printf("%f celcius is equal to %f farenheit", celcius, farenhiet);
    return 0;
}